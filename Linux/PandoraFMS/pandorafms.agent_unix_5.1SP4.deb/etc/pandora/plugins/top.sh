echo "<module>";
echo "<name>top</name>";
echo "<type>generic_data_string</type>";
echo "<data><![CDATA["
top -b -n 1
echo "]]></data>"
echo "</module>"

